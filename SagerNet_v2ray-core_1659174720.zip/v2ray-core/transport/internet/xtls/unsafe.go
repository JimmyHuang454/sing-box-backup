package xtls

import _ "unsafe"

//go:linkname errNoCertificates github.com/xtls/go.errNoCertificates
var errNoCertificates error
