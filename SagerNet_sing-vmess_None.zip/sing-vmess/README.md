# sing-vmess

Some confusing protocol.

### Features

100% compatible with `v2ray-core`.

* Stream length chunk with padding and masking
* AEAD length chunk with padding
* Stream chunk
* AEAD chunk
* Legacy client
* AEAD client
* Legacy server
* AEAD server

Extra features:

* Mux server
* XUDP client
* VLESS client
