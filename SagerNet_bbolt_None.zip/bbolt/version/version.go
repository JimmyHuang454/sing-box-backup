package version

// Version shows the last bbolt binary version released.
var Version = "1.3.7"
