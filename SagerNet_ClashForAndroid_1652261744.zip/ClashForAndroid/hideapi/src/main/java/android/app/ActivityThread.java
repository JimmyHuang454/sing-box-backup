package android.app;

public class ActivityThread {
    public static String currentProcessName() {
        throw new IllegalArgumentException("Stub!");
    }
}
