package com.github.kr328.clash

import android.app.Application

@Suppress("UNUSED_PARAMETER")
object Tracker {
    fun initialize(application: Application) {
        // do nothing
    }

    fun uploadLogcat(logcat: String) {
        // do nothing
    }
}