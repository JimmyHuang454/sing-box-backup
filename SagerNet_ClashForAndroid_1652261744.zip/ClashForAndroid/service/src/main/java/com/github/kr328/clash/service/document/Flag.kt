package com.github.kr328.clash.service.document

enum class Flag {
    Writable, Deletable, Virtual
}