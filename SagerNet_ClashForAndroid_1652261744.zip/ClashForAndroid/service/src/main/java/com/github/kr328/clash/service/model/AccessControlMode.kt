package com.github.kr328.clash.service.model

enum class AccessControlMode {
    AcceptAll, AcceptSelected, DenySelected
}
