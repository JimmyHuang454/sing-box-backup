## Contributing to Clash for Android

#### Code Style

Please use `Android Studio` or `Intellij IDEA` to open the project and use the project code style profile.

`File` -> `Settings` -> `Editor` -> `Code Style` -> `C/C++ and Kotlin` -> `Scheme` -> `Project`



#### License

Contributing to Clash for Android that assumes you allow code to be merged into closed-source branch of Clash for Android. Other terms follow the [GPLv3](https://www.gnu.org/licenses/gpl-3.0.html)

