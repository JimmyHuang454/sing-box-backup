# ClashForAndroid for SagerNet

### Changes

* See https://github.com/SagerNet/clash