package com.github.kr328.clash.common.util

import com.github.kr328.clash.common.Global

val packageName: String = Global.application.packageName