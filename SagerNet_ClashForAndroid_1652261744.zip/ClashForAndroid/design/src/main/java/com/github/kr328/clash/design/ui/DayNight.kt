package com.github.kr328.clash.design.ui

enum class DayNight {
    Day, Night
}