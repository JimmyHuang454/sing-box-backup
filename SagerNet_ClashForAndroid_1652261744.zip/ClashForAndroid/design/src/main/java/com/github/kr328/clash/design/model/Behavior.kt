package com.github.kr328.clash.design.model

interface Behavior {
    var autoRestart: Boolean
}