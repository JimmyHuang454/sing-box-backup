package com.github.kr328.clash.design.model

class ProxyPageState {
    var bottom = false
    var urlTesting = false
}