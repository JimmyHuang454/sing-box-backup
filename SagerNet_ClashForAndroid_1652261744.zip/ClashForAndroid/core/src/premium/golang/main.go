package main

import _ "cfa/native/all"
