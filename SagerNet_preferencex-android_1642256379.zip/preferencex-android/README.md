# PreferenceX

Fixed version of https://github.com/takisoft/preferencex-android

Used directly in SagerNet as a submodule, because the original artifacts are hosted in the deprecated jcenter)