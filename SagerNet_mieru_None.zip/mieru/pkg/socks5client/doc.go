// Package socks5client is imported from https://github.com/h12w/socks
package socks5client

// Testing port range: [12300, 12305).
