// Package kcp is imported from https://github.com/xtaci/kcp-go
package kcp

// Testing port range: [12305, 12315).
