// Package socks5 is imported from https://github.com/armon/go-socks5
package socks5

// Testing port range: [12345, 12350).
