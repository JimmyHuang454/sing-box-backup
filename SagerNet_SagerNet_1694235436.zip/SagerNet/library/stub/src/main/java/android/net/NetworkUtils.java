package android.net;

public class NetworkUtils {

    public static boolean protectFromVpn(int socketfd) {
        return false;
    }

}
