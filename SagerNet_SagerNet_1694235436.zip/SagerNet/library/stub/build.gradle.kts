plugins {
    id("com.android.library")
}

setupCommon()