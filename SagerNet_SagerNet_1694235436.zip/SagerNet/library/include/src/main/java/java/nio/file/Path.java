package java.nio.file;

public interface Path {}
