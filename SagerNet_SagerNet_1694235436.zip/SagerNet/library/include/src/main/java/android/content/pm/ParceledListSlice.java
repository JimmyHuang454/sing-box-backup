package android.content.pm;

public class ParceledListSlice<T> extends BaseParceledListSlice<T> {
}
