package android.app;

public class ActivityThread {

    public static String currentProcessName() {
        return null;
    }

}
