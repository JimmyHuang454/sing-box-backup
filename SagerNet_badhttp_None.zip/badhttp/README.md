# badhttp

Go net/http with abstract TLS interface

Version: go1.20.1