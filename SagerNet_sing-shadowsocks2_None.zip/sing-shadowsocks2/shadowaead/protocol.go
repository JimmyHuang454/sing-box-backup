package shadowaead

const MaxPacketSize = 16*1024 - 1
