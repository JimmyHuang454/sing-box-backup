# sing-shadowsocks2

Yet another shadowsocks implementation.

TODO:

* [x] Client
* [ ] Server
