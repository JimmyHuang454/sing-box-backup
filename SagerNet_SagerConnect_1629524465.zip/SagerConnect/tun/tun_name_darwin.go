package tun

const DefaultTunName = "utun10"
