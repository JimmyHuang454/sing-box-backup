// +build !darwin,!windows

package tun

const DefaultTunName = "tun0"
