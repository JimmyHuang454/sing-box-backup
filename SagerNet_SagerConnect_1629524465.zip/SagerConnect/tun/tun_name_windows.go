package tun

const DefaultTunName = "SagerConnect"
