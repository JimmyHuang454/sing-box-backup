# Docker V2Ray

docker build repo for v2ray

https://hub.docker.com/r/sagernet/v2ray-core
