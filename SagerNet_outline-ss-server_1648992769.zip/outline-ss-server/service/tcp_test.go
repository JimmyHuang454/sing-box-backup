// Copyright 2018 Jigsaw Operations LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package service

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net"
	"sync"
	"testing"
	"time"

	onet "github.com/Shadowsocks-NET/outline-ss-server/net"
	"github.com/Shadowsocks-NET/outline-ss-server/service/metrics"
	ss "github.com/Shadowsocks-NET/outline-ss-server/shadowsocks"
	"github.com/Shadowsocks-NET/outline-ss-server/socks"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"
)

func init() {
	logger, err := zap.NewDevelopment()
	if err != nil {
		panic(err)
	}
	SetLogger(logger)
}

func makeLocalhostListener(t testing.TB) *net.TCPListener {
	listener, err := net.ListenTCP("tcp", &net.TCPAddr{IP: net.IPv6loopback, Port: 0})
	require.Nil(t, err, "ListenTCP failed: %v", err)
	return listener
}

func startDiscardServer(t testing.TB) (*net.TCPListener, *sync.WaitGroup) {
	listener := makeLocalhostListener(t)
	var running sync.WaitGroup
	running.Add(1)
	go func() {
		defer running.Done()
		for {
			clientConn, err := listener.AcceptTCP()
			if err != nil {
				t.Logf("AcceptTCP failed: %v", err)
				return
			}
			running.Add(1)
			go func() {
				defer running.Done()
				io.Copy(io.Discard, clientConn)
				clientConn.Close()
			}()
		}
	}()
	return listener, &running
}

// Simulates receiving invalid TCP connection attempts on a server with 100 ciphers.
func BenchmarkTCPFindCipherFail(b *testing.B) {
	b.StopTimer()
	b.ResetTimer()

	listener, err := net.ListenTCP("tcp", &net.TCPAddr{IP: net.IPv6loopback, Port: 0})
	if err != nil {
		b.Fatalf("ListenTCP failed: %v", err)
	}

	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(100))
	if err != nil {
		b.Fatal(err)
	}
	testPayload := ss.MakeTestPayload(50)
	for n := 0; n < b.N; n++ {
		ch := make(chan error, 1)
		go func() {
			conn, err := net.Dial("tcp", listener.Addr().String())
			ch <- err
			if err != nil {
				return
			}
			conn.Write(testPayload)
			conn.Close()
		}()
		err := <-ch
		if err != nil {
			b.Fatalf("Failed to dial %v: %v", listener.Addr(), err)
		}
		clientConn, err := listener.AcceptTCP()
		if err != nil {
			b.Fatalf("AcceptTCP failed: %v", err)
		}
		clientIP := clientConn.RemoteAddr().(*net.TCPAddr).IP
		b.StartTimer()
		findAccessKey(clientConn, clientIP, cipherList)
		b.StopTimer()
	}
}

func TestCompatibleCiphers(t *testing.T) {
	for _, cipherName := range ss.SupportedCipherNames() {
		cipher, _ := ss.NewCipher(cipherName, "dummy secret")
		// We need at least this many bytes to assess whether a TCP stream corresponds
		// to this cipher.
		requires := cipher.SaltSize() + 2 + cipher.TagSize()
		if requires > bytesForKeyFinding {
			t.Errorf("Cipher %v required %v bytes > bytesForKeyFinding (%v)", cipherName, requires, bytesForKeyFinding)
		}
		// Any TCP stream for this cipher will deliver at least this many bytes before
		// requiring the proxy to act.
		provides := requires + cipher.TagSize()
		if provides < bytesForKeyFinding {
			t.Errorf("Cipher %v provides %v bytes < bytesForKeyFinding (%v)", cipherName, provides, bytesForKeyFinding)
		}
	}
}

// Fake DuplexConn
// 1-way pipe, representing the upstream flow as seen by the server.
type conn struct {
	onet.DuplexConn
	clientAddr net.Addr
	reader     io.ReadCloser
	writer     io.WriteCloser
}

func (c *conn) Read(b []byte) (int, error) {
	return c.reader.Read(b)
}

func (c *conn) Write(b []byte) (int, error) {
	// Any downstream data is ignored.
	return len(b), nil
}

func (c *conn) Close() error {
	e1 := c.reader.Close()
	e2 := c.writer.Close()
	if e1 != nil {
		return e1
	}
	return e2
}

func (c *conn) LocalAddr() net.Addr {
	return nil
}

func (c *conn) RemoteAddr() net.Addr {
	return c.clientAddr
}

func (c *conn) SetDeadline(t time.Time) error {
	return errors.New("SetDeadline is not supported")
}

func (c *conn) SetReadDeadline(t time.Time) error {
	return errors.New("SetDeadline is not supported")
}

func (c *conn) SetWriteDeadline(t time.Time) error {
	return errors.New("SetDeadline is not supported")
}

func (c *conn) CloseRead() error {
	return c.reader.Close()
}

func (c *conn) CloseWrite() error {
	return nil
}

// Simulates receiving valid TCP connection attempts from 100 different users,
// each with their own cipher and their own IP address.
func BenchmarkTCPFindCipherRepeat(b *testing.B) {
	b.StopTimer()
	b.ResetTimer()

	const numCiphers = 100 // Must be <256
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(numCiphers))
	if err != nil {
		b.Fatal(err)
	}
	cipherEntries := [numCiphers]*CipherEntry{}
	snapshot := cipherList.SnapshotForClientIP(nil)
	for cipherNumber, element := range snapshot {
		cipherEntries[cipherNumber] = element.Value.(*CipherEntry)
	}
	for n := 0; n < b.N; n++ {
		cipherNumber := byte(n % numCiphers)
		reader, writer := io.Pipe()
		clientIP := net.IPv4(192, 0, 2, cipherNumber)
		addr := &net.TCPAddr{IP: clientIP, Port: 54321}
		c := conn{clientAddr: addr, reader: reader, writer: writer}
		cipher := cipherEntries[cipherNumber].Cipher
		ssw, err := ss.NewShadowsocksWriter(writer, cipher, nil, nil, cipher.Config().IsSpec2022)
		if err != nil {
			b.Fatal(err)
		}
		go ssw.Write(ss.MakeTestPayload(50))
		b.StartTimer()
		_, _, _, _, err = findAccessKey(&c, clientIP, cipherList)
		b.StopTimer()
		if err != nil {
			b.Error(err)
		}
		c.Close()
	}
}

// Stub metrics implementation for testing replay defense.
type probeTestMetrics struct {
	metrics.ShadowsocksMetrics
	mu          sync.Mutex
	probeData   []metrics.ProxyMetrics
	probeStatus []string
	closeStatus []string
}

func (m *probeTestMetrics) AddTCPProbe(clientLocation, status, drainResult string, port int, data metrics.ProxyMetrics) {
	m.mu.Lock()
	m.probeData = append(m.probeData, data)
	m.probeStatus = append(m.probeStatus, status)
	m.mu.Unlock()
}
func (m *probeTestMetrics) AddClosedTCPConnection(clientLocation, accessKey, status string, data metrics.ProxyMetrics, timeToCipher, duration time.Duration) {
	m.mu.Lock()
	m.closeStatus = append(m.closeStatus, status)
	m.mu.Unlock()
}

func (m *probeTestMetrics) GetLocation(net.Addr) (string, error) {
	return "", nil
}
func (m *probeTestMetrics) SetNumAccessKeys(numKeys int, numPorts int) {
}
func (m *probeTestMetrics) AddOpenTCPConnection(clientLocation string) {
}
func (m *probeTestMetrics) AddUDPPacketFromClient(clientLocation, accessKey, status string, clientProxyBytes, proxyTargetBytes int, timeToCipher time.Duration) {
}
func (m *probeTestMetrics) AddUDPPacketFromTarget(clientLocation, accessKey, status string, targetProxyBytes, proxyClientBytes int) {
}
func (m *probeTestMetrics) AddUDPNatEntry()    {}
func (m *probeTestMetrics) RemoveUDPNatEntry() {}

func (m *probeTestMetrics) countStatuses() map[string]int {
	counts := make(map[string]int)
	for _, status := range m.closeStatus {
		counts[status] = counts[status] + 1
	}
	return counts
}

func probe(serverAddr *net.TCPAddr, bytesToSend []byte) error {
	conn, err := net.DialTCP("tcp", nil, serverAddr)
	if err != nil {
		return fmt.Errorf("DialTCP failed: %w", err)
	}

	n, err := conn.Write(bytesToSend)
	if err != nil || n != len(bytesToSend) {
		return fmt.Errorf("Write failed. bytes written: %v, err: %v", n, err)
	}
	conn.CloseWrite()

	nRead, err := conn.Read(make([]byte, 1))
	if err != io.EOF || nRead != 0 {
		return fmt.Errorf("Read not EOF. bytes read: %v, err: %v", nRead, err)
	}
	return nil
}

func TestProbeRandom(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	testMetrics := &probeTestMetrics{}
	s := NewTCPService(cipherList, nil, nil, testMetrics, 200*time.Millisecond, false)
	go s.Serve(listener)

	// 221 is the largest random probe reported by https://gfw.report/blog/gfw_shadowsocks/
	buf := make([]byte, 221)
	for numBytesToSend := 0; numBytesToSend < len(buf); numBytesToSend++ {
		bytesToSend := buf[:numBytesToSend]
		rand.Read(bytesToSend)
		err := probe(listener.Addr().(*net.TCPAddr), bytesToSend)
		require.Nil(t, err, "Failed on byte %v: %v", numBytesToSend, err)
	}
	s.GracefulStop()
	require.Equal(t, len(buf), len(testMetrics.probeData))
}

func makeClientBytesBasic(t *testing.T, cipher *ss.Cipher, targetAddr string) []byte {
	var buffer bytes.Buffer
	socksTargetAddr, err := socks.ParseAddr(targetAddr)
	require.Nil(t, err, "ParseAddr failed: %v", err)
	require.Equal(t, 1+16+2, len(socksTargetAddr))
	ssw, err := ss.NewShadowsocksWriter(&buffer, cipher, nil, nil, false)
	require.Nil(t, err, "NewShadowsocksWriter failed: %v", err)
	n, err := ssw.Write(socksTargetAddr)
	require.Nil(t, err, "Write failed: %v", err)
	require.Equal(t, len(socksTargetAddr), n, "Write failed: %v", err)
	require.Equal(t, 32+2+16+19+16, buffer.Len()) // 73

	payload := make([]byte, 100)
	rand.Read(payload)
	_, err = ssw.Write(payload[:60])
	require.Nil(t, err, "Write failed: %v", err)
	require.Equal(t, 85+2+16+60+16, buffer.Len()) // 167

	_, err = ssw.Write(payload[60:])
	require.Nil(t, err, "Write failed: %v", err)
	require.Equal(t, 179+2+16+40+16, buffer.Len()) // 241

	return buffer.Bytes()
}

func makeClientBytesCoalesced(t *testing.T, cipher *ss.Cipher, targetAddr string) []byte {
	var buffer bytes.Buffer
	socksTargetAddr, err := socks.ParseAddr(targetAddr)
	require.Nil(t, err, "ParseAddr failed: %v", err)
	ssw, err := ss.NewShadowsocksWriter(&buffer, cipher, nil, socksTargetAddr, false)
	require.Nil(t, err, "NewShadowsocksWriter failed: %v", err)
	_, err = ssw.Write([]byte("initial data"))
	require.Nil(t, err, "Write failed: %v", err)
	require.Equal(t, 32+2+16+19+12+16, buffer.Len()) // 85

	_, err = ssw.Write([]byte("more data"))
	require.Nil(t, err, "Write failed: %v", err)
	return buffer.Bytes()
}

func firstCipher(cipherList CipherList) *ss.Cipher {
	snapshot := cipherList.SnapshotForClientIP(nil)
	cipherEntry := snapshot[0].Value.(*CipherEntry)
	return cipherEntry.Cipher
}

func TestProbeClientBytesBasicTruncated(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	cipher := firstCipher(cipherList)
	testMetrics := &probeTestMetrics{}
	s := NewTCPService(cipherList, nil, nil, testMetrics, 200*time.Millisecond, false)
	go s.Serve(listener)

	discardListener, discardWait := startDiscardServer(t)
	initialBytes := makeClientBytesBasic(t, cipher, discardListener.Addr().String())
	for numBytesToSend := 0; numBytesToSend < len(initialBytes); numBytesToSend++ {
		t.Logf("Sending %v bytes", numBytesToSend)
		bytesToSend := initialBytes[:numBytesToSend]
		err := probe(listener.Addr().(*net.TCPAddr), bytesToSend)
		require.Nil(t, err, "Failed for %v bytes sent: %v", numBytesToSend, err)
	}
	s.GracefulStop()
	statusCount := testMetrics.countStatuses()
	require.Equal(t, 50, statusCount["ERR_CIPHER"])
	require.Equal(t, 19+16, statusCount["ERR_READ_HEADER"])
	require.Equal(t, 2, statusCount["OK"]) // On the chunk boundaries.
	require.Equal(t, len(initialBytes)-50-19-16-2, statusCount["ERR_RELAY_CLIENT"])
	// We only count as probes failures in the first 50 bytes.
	require.Equal(t, 50, len(testMetrics.probeData))
	discardListener.Close()
	discardWait.Wait()
}

func TestProbeClientBytesBasicModified(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	cipher := firstCipher(cipherList)
	testMetrics := &probeTestMetrics{}
	s := NewTCPService(cipherList, nil, nil, testMetrics, 200*time.Millisecond, false)
	go s.Serve(listener)

	discardListener, discardWait := startDiscardServer(t)
	initialBytes := makeClientBytesBasic(t, cipher, discardListener.Addr().String())
	bytesToSend := make([]byte, len(initialBytes))
	for byteToModify := 0; byteToModify < len(initialBytes); byteToModify++ {
		t.Logf("Modifying byte %v", byteToModify)
		copy(bytesToSend, initialBytes)
		bytesToSend[byteToModify] = 255 - bytesToSend[byteToModify]
		err := probe(listener.Addr().(*net.TCPAddr), bytesToSend)
		require.Nil(t, err, "Failed modified byte %v: %v", byteToModify, err)
	}

	s.GracefulStop()
	statusCount := testMetrics.countStatuses()
	require.Equal(t, 50, statusCount["ERR_CIPHER"])
	require.Equal(t, 19+16, statusCount["ERR_READ_HEADER"])
	require.Equal(t, len(initialBytes)-50-19-16, statusCount["ERR_RELAY_CLIENT"])
	require.Equal(t, 50, len(testMetrics.probeData))
	discardListener.Close()
	discardWait.Wait()
}

func TestProbeClientBytesCoalescedModified(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	cipher := firstCipher(cipherList)
	testMetrics := &probeTestMetrics{}
	s := NewTCPService(cipherList, nil, nil, testMetrics, 200*time.Millisecond, false)
	go s.Serve(listener)

	discardListener, discardWait := startDiscardServer(t)
	initialBytes := makeClientBytesCoalesced(t, cipher, discardListener.Addr().String())
	bytesToSend := make([]byte, len(initialBytes))
	for byteToModify := 0; byteToModify < len(initialBytes); byteToModify++ {
		t.Logf("Modifying byte %v", byteToModify)
		copy(bytesToSend, initialBytes)
		bytesToSend[byteToModify] = 255 - bytesToSend[byteToModify]
		err := probe(listener.Addr().(*net.TCPAddr), bytesToSend)
		require.Nil(t, err, "Failed modified byte %v: %v", byteToModify, err)
	}
	s.GracefulStop()
	statusCount := testMetrics.countStatuses()
	require.Equal(t, 50, statusCount["ERR_CIPHER"])
	require.Equal(t, len(initialBytes)-50, statusCount["ERR_READ_HEADER"]+statusCount["ERR_RELAY_CLIENT"])
	discardListener.Close()
	discardWait.Wait()
}

func makeServerBytes(t *testing.T, cipher *ss.Cipher, targetAddr string) []byte {
	var buffer bytes.Buffer
	socksTargetAddr, err := socks.ParseAddr(targetAddr)
	require.Nil(t, err, "ParseAddr failed: %v", err)
	ssw, err := ss.NewShadowsocksWriter(&buffer, cipher, nil, nil, false)
	require.Nil(t, err, "NewShadowsocksWriter failed: %v", err)
	_, err = ssw.Write(socksTargetAddr)
	require.Nil(t, err, "Write failed: %v", err)
	_, err = ssw.Write([]byte("initial data"))
	require.Nil(t, err, "Write failed: %v", err)
	_, err = ssw.Write([]byte("more data"))
	require.Nil(t, err, "Write failed: %v", err)
	return buffer.Bytes()
}

func TestProbeServerBytesModified(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	cipher := firstCipher(cipherList)
	testMetrics := &probeTestMetrics{}
	s := NewTCPService(cipherList, nil, nil, testMetrics, 200*time.Millisecond, false)
	go s.Serve(listener)

	discardListener, discardWait := startDiscardServer(t)
	initialBytes := makeServerBytes(t, cipher, discardListener.Addr().String())
	bytesToSend := make([]byte, len(initialBytes))
	for byteToModify := 0; byteToModify < len(initialBytes); byteToModify++ {
		copy(bytesToSend, initialBytes)
		bytesToSend[byteToModify] = 255 - bytesToSend[byteToModify]
		err := probe(listener.Addr().(*net.TCPAddr), bytesToSend)
		require.Nil(t, err, "Failed modified byte %v: %v", byteToModify, err)
	}
	s.GracefulStop()
	statusCount := testMetrics.countStatuses()
	require.Equal(t, 50, statusCount["ERR_CIPHER"])
	require.Equal(t, 19+16, statusCount["ERR_READ_HEADER"])
	require.Equal(t, 50, len(testMetrics.probeData))
	discardListener.Close()
	discardWait.Wait()
}

func TestReplayDefense(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	replayCache := NewReplayCache(5)
	saltPool := NewSaltPool()
	testMetrics := &probeTestMetrics{}
	const testTimeout = 200 * time.Millisecond
	s := NewTCPService(cipherList, &replayCache, saltPool, testMetrics, testTimeout, false)
	snapshot := cipherList.SnapshotForClientIP(nil)
	cipherEntry := snapshot[0].Value.(*CipherEntry)
	cipher := cipherEntry.Cipher
	reader, writer := io.Pipe()
	ssw, err := ss.NewShadowsocksWriter(writer, cipher, nil, nil, cipher.Config().IsSpec2022)
	go ssw.Write([]byte{0})
	preamble := make([]byte, cipher.SaltSize()+2+cipher.TagSize())
	if _, err := io.ReadFull(reader, preamble); err != nil {
		t.Fatal(err)
	}

	run := func() *net.TCPConn {
		conn, err := net.DialTCP(listener.Addr().Network(), nil, listener.Addr().(*net.TCPAddr))
		if err != nil {
			t.Fatal(err)
		}
		n, err := conn.Write(preamble)
		if n < len(preamble) {
			t.Error(err)
		}
		return conn
	}

	go s.Serve(listener)

	// First run.
	conn1 := run()
	// Wait for the close.  This ensures that conn1 and conn2 can't be
	// processed out of order at the proxy.
	conn1.CloseWrite()
	conn1.Read(make([]byte, 1))
	if len(testMetrics.probeData) != 0 {
		t.Errorf("First connection should not have triggered probe detection: %v", testMetrics.probeData[0])
	}

	// Replay.
	conn2 := run()
	// Wait for the connection to be closed by the proxy after testTimeout.
	conn2.CloseWrite()
	conn2.Read(make([]byte, 1))

	conn1.Close()
	s.GracefulStop()

	if len(testMetrics.probeData) == 1 {
		data := testMetrics.probeData[0]
		if data.ClientProxy != int64(len(preamble)) {
			t.Errorf("Unexpected probe data: %v", data)
		}
		status := testMetrics.probeStatus[0]
		if status != "ERR_REPLAY_CLIENT" {
			t.Errorf("Unexpected TCP probe status: %s", status)
		}
	} else {
		t.Error("Replay should have triggered probe detection")
	}
	if len(testMetrics.closeStatus) == 2 {
		status := testMetrics.closeStatus[1]
		if status != "ERR_REPLAY_CLIENT" {
			t.Errorf("Unexpected TCP close status: %s", status)
		}
	} else {
		t.Error("Replay should have reported an error status")
	}
}

func TestReverseReplayDefense(t *testing.T) {
	listener := makeLocalhostListener(t)
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	replayCache := NewReplayCache(5)
	saltPool := NewSaltPool()
	testMetrics := &probeTestMetrics{}
	const testTimeout = 200 * time.Millisecond
	s := NewTCPService(cipherList, &replayCache, saltPool, testMetrics, testTimeout, false)
	snapshot := cipherList.SnapshotForClientIP(nil)
	cipherEntry := snapshot[0].Value.(*CipherEntry)
	cipher := cipherEntry.Cipher
	reader, writer := io.Pipe()
	// Use a server-marked salt in the client's preamble.
	ssWriter, err := ss.NewShadowsocksWriter(writer, cipher, cipherEntry.SaltGenerator, nil, cipher.Config().IsSpec2022)
	go ssWriter.Write([]byte{0})
	preamble := make([]byte, 32+2+16)
	if _, err := io.ReadFull(reader, preamble); err != nil {
		t.Fatal(err)
	}

	go s.Serve(listener)

	conn, err := net.Dial(listener.Addr().Network(), listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	n, err := conn.Write(preamble)
	if n < len(preamble) {
		t.Error(err)
	}
	conn.Close()
	s.GracefulStop()

	// The preamble should have been marked as a server replay.
	if len(testMetrics.probeData) == 1 {
		data := testMetrics.probeData[0]
		if data.ClientProxy != int64(len(preamble)) {
			t.Errorf("Unexpected probe data: %v", data)
		}
		status := testMetrics.probeStatus[0]
		if status != "ERR_REPLAY_SERVER" {
			t.Errorf("Unexpected TCP probe status: %s", status)
		}
	} else {
		t.Error("Replay should have triggered probe detection")
	}
	if len(testMetrics.closeStatus) == 1 {
		status := testMetrics.closeStatus[0]
		if status != "ERR_REPLAY_SERVER" {
			t.Errorf("Unexpected TCP close status: %s", status)
		}
	} else {
		t.Error("Replay should have reported an error status")
	}
}

func TestTCPDoubleServe(t *testing.T) {
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	replayCache := NewReplayCache(5)
	saltPool := NewSaltPool()
	testMetrics := &probeTestMetrics{}
	const testTimeout = 200 * time.Millisecond
	s := NewTCPService(cipherList, &replayCache, saltPool, testMetrics, testTimeout, false)

	c := make(chan error)
	for i := 0; i < 2; i++ {
		listener := makeLocalhostListener(t)
		go func() {
			err := s.Serve(listener)
			if err != nil {
				c <- err
				close(c)
			}
		}()
	}

	err = <-c
	if err == nil {
		t.Error("Expected an error from one of the two Serve calls")
	}

	if err := s.Stop(); err != nil {
		t.Error(err)
	}
}

func TestTCPEarlyStop(t *testing.T) {
	cipherList, err := MakeTestCiphers(ss.MakeTestSecrets(1))
	require.Nil(t, err, "MakeTestCiphers failed: %v", err)
	replayCache := NewReplayCache(5)
	saltPool := NewSaltPool()
	testMetrics := &probeTestMetrics{}
	const testTimeout = 200 * time.Millisecond
	s := NewTCPService(cipherList, &replayCache, saltPool, testMetrics, testTimeout, false)

	if err := s.Stop(); err != nil {
		t.Error(err)
	}
	listener := makeLocalhostListener(t)
	if err := s.Serve(listener); err != nil {
		t.Error(err)
	}
}
