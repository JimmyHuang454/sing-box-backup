# Outline Shadowsocks

[![Build](https://github.com/Shadowsocks-NET/outline-ss-server/actions/workflows/build.yml/badge.svg)](https://github.com/Shadowsocks-NET/outline-ss-server/actions/workflows/build.yml)
[![Release](https://github.com/Shadowsocks-NET/outline-ss-server/actions/workflows/release.yml/badge.svg)](https://github.com/Shadowsocks-NET/outline-ss-server/actions/workflows/release.yml)

An opinionated fork of Jigsaw-Code/outline-ss-server.
