package core

/*
#include "c/core/ipv6/dhcp6.c"
#include "c/core/ipv6/ethip6.c"
#include "c/core/ipv6/icmp6.c"
#include "c/core/ipv6/inet6.c"
#include "c/core/ipv6/ip6.c"
#include "c/core/ipv6/ip6_addr.c"
#include "c/core/ipv6/ip6_frag.c"
#include "c/core/ipv6/mld6.c"
#include "c/core/ipv6/nd6.c"
*/
import "C"
