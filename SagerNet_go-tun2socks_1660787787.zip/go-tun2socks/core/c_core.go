package core

/*
#include "c/core/init.c"
#include "c/core/def.c"
#include "c/core/dns.c"
#include "c/core/inet_chksum.c"
#include "c/core/ip.c"
#include "c/core/mem.c"
#include "c/core/memp.c"
#include "c/core/netif.c"
#include "c/core/pbuf.c"
#include "c/core/raw.c"
#include "c/core/stats.c"
#include "c/core/sys.c"
#include "c/core/tcp.c"
#include "c/core/tcp_in.c"
#include "c/core/tcp_out.c"
#include "c/core/timeouts.c"
#include "c/core/udp.c"
*/
import "C"
