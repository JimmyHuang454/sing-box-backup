#ifndef __ARCH_SYS_ARCH_H__
#define __ARCH_SYS_ARCH_H__

#define SYS_MBOX_NULL   NULL
#define SYS_SEM_NULL    NULL

#endif /* __ARCH_SYS_ARCH_H__ */
