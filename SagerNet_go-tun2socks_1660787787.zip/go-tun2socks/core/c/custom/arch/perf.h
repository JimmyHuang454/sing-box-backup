#ifndef perf_h
#define perf_h

#define PERF_START
#define PERF_STOP(x)

#endif /* perf_h */
