import Foundation

public class MacLibrary {}
