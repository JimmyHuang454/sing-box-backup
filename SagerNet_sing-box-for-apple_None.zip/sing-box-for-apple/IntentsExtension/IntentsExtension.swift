import AppIntents

@main
struct IntentsExtension: AppIntentsExtension {}
