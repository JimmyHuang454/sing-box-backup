import Foundation

public class Library {}
