#if os(macOS)

    import Library
    import SwiftUI

    @MainActor
    public struct InstallSystemExtensionButton: View {
        @State private var alert: Alert?
        private let callback: () async -> Void
        public init(_ callback: @escaping () async -> Void) {
            self.callback = callback
        }

        public var body: some View {
            Button("Install SystemExtension") {
                Task {
                    await installSystemExtension()
                }
            }
            .alertBinding($alert)
        }

        private func installSystemExtension() async {
            do {
                if let result = try await SystemExtension.install() {
                    if result == .willCompleteAfterReboot {
                        alert = Alert(errorMessage: "Need Reboot")
                    }
                }
                await callback()
            } catch {
                alert = Alert(error)
            }
        }
    }

#endif
