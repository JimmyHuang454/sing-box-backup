import Foundation

public class ApplicationLibrary {
    public static let bundle = Bundle(for: ApplicationLibrary.self)
    public static let inPreview = false
}
