//go:build !android
// +build !android

package core

func protectFd(s uintptr) error {
}
