# sing-shadowtls

Go implementation of https://github.com/ihciah/shadow-tls