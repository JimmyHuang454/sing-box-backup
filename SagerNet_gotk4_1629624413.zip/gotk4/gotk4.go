package gotk4

//go:generate go run ./gir/cmd/gir_generate -o ./pkg/
