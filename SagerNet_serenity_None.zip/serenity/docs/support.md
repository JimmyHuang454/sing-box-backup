#### Github

Issue: [Issues · SagerNet/serenity](https://github.com/SagerNet/serenity/issues)

#### Telegram

Notification channel: [@yapnc](https://t.me/yapnc)  
User group: [@yapug](https://t.me/yapug)