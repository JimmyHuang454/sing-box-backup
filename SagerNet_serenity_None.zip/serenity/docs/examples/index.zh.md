# 示例

serenity 的配置示例。

* [Linux 服务器安装](./linux-server-installation)
