# Examples

Configuration examples for serenity.

* [Linux Server Installation](./linux-server-installation)
