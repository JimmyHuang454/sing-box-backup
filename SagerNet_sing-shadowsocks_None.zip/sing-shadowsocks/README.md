# sing-shadowsocks

Lightweight and efficient shadowsocks implementation with sing.