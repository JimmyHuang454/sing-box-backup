package comm

const (
	IPv6Disable = iota
	IPv6Enable
	IPv6Prefer
	IPv6Only
)
