package comm

const (
	TunImplementationGVisor = iota
	TunImplementationSystem
)
