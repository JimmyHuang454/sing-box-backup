//go:build force_stdio

package bufio

// force_stdio is dedicated to testing exposed stdio APIs.
const forceSTDIO = true
