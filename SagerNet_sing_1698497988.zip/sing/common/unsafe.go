//go:build unsafe_buffer && !disable_unsafe_buffer

package common

const UnsafeBuffer = true
