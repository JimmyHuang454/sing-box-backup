# x/list

`list` with generic type

upstream: go1.18