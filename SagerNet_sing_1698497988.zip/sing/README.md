# sing

Do you hear the people sing?