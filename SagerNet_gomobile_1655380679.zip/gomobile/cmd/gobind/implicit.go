// This file imports implicit dependencies required by generated code.

//go:build mobile_implicit
// +build mobile_implicit

package main

import (
	_ "github.com/sagernet/gomobile/bind"
	_ "github.com/sagernet/gomobile/bind/java"
	_ "github.com/sagernet/gomobile/bind/objc"
)
