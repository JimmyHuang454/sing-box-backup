package cgopkg

import "C"

import (
	_ "github.com/sagernet/gomobile/gl"
)

func Dummy() {}
