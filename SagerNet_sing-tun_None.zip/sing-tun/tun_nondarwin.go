//go:build !darwin

package tun

const PacketOffset = 0
