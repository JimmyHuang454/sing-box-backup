# `tfo-go`

`tfo-go` provides TCP Fast Open support for the `net` dialer and listener.

```bash
go get github.com/sagernet/tfo-go
```

## License

[MIT](LICENSE)
