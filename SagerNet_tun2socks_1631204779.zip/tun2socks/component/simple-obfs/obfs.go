// Package obfs provides obfuscation functionality for Shadowsocks protocol.
package obfs

// Ref: github.com/Dreamacro/clash/component/simple-obfs
