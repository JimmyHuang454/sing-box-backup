package constant

const (
	Name = "tun2socks"
)

var (
	Version   string
	GitCommit string
)
