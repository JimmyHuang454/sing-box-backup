// Package stats provides statistic data via http server.
package stats

// Ref: github.com/Dreamacro/clash/hub/route
