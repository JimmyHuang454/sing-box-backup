package smux

import (
	"github.com/sagernet/sing/common/buf"
)

var defaultAllocator = buf.DefaultAllocator
