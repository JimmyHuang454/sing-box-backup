package constant

var Version = "unknown"
