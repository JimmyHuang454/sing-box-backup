package constant

const (
	ProtocolTLS  = "tls"
	ProtocolHTTP = "http"
	ProtocolQUIC = "quic"
	ProtocolDNS  = "dns"
	ProtocolSTUN = "stun"
)
