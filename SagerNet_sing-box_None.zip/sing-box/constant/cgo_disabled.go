//go:build !cgo

package constant

const CGO_ENABLED = false
