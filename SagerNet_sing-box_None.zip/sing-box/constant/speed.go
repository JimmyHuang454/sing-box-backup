package constant

const MbpsToBps = 125000
