package constant

import "time"

const (
	DHCPTTL     = time.Hour
	DHCPTimeout = time.Minute
)
