# Examples

Configuration examples for sing-box.

* [Linux Server Installation](./linux-server-installation)
* [Tun](./tun)
* [DNS Hijack](./dns-hijack.md)
* [Shadowsocks](./shadowsocks)
* [ShadowTLS](./shadowtls)
* [Clash API](./clash-api)
* [FakeIP](./fakeip)
