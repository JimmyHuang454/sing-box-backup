# 示例

sing-box 的配置示例。

* [Linux 服务器安装](./linux-server-installation)
* [Tun](./tun)
* [DNS 劫持](./dns-hijack.md)
* [Shadowsocks](./shadowsocks)
* [ShadowTLS](./shadowtls)
* [Clash API](./clash-api)
* [FakeIP](./fakeip)
