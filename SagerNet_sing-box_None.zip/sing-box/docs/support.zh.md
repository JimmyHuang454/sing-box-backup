Github 工单: [Issues · SagerNet/sing-box](https://github.com/SagerNet/sing-box/issues)  
Telegram 通知频道: [@yapnc](https://t.me/yapnc)  
Telegram 用户组: [@yapug](https://t.me/yapug)  
Email: [contact@sagernet.org](mailto:contact@sagernet.org)
