!!! error ""

    Only supported on Linux.

### Structure

```json
{
  "type": "tproxy",
  "tag": "tproxy-in",

  ... // Listen Fields

  "network": "udp"
}
```

### Listen Fields

See [Listen Fields](/configuration/shared/listen) for details.

### Fields

#### network

Listen network, one of `tcp` `udp`.

Both if empty.
