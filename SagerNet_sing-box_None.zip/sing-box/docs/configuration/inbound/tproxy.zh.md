!!! error ""

    仅支持 Linux。

### 结构

```json
{
  "type": "tproxy",
  "tag": "tproxy-in",

  ... // 监听字段

  "network": "udp"
}
```

### 监听字段

参阅 [监听字段](/zh/configuration/shared/listen/)。

### 字段

#### network

监听的网络协议，`tcp` `udp` 之一。

默认所有。
