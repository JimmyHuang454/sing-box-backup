# simple-obfs

mod from https://github.com/Dreamacro/clash/transport/simple-obfs
version: 1.11.8