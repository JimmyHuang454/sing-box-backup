//go:build with_conntrack

package conntrack

const Enabled = true
