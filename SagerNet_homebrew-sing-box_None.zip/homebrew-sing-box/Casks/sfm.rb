cask "sfm" do
  version "1.5.2"
  sha256 "8f9a32784cf8075a18a4cd261555681107ee9ac3eb0bcb97586b03e7075c7e8b"

  url "https://github.com/SagerNet/sing-box/releases/download/v#{version}/SFM-#{version}-universal.zip",
      verified: "github.com/SagerNet/sing-box/"
  name "SFM"
  desc "Standalone client for sing-box, the universal proxy platform"
  homepage "https://sing-box.sagernet.org/"

  depends_on macos: ">= :ventura"

  app "SFM.app"

  uninstall quit: "io.nekohasekai.sfa.independent", login_item: "SFM"

  zap trash: [
    "~/Library/Group Containers/group.io.nekohasekai.sfa",
  ]
end
