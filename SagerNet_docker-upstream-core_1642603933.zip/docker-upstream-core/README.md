# Docker Fly

docker build repo for v2fly

https://hub.docker.com/r/v2fly/v2fly-core
