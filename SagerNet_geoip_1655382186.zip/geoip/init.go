package main

import (
	_ "github.com/v2fly/geoip/plugin/maxmind"
	_ "github.com/v2fly/geoip/plugin/plaintext"
	_ "github.com/v2fly/geoip/plugin/special"
	_ "github.com/v2fly/geoip/plugin/v2ray"
)
