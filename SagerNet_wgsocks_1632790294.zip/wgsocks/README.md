# wgsocks

Simple WireGuard to socks5 wrapper, used by SagerNet.