---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
Before submitting a feature request or suggestion, please check the open issues to avoid duplication.
-->


