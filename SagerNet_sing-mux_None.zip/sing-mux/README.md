# sing-mux

Simple multiplex library.