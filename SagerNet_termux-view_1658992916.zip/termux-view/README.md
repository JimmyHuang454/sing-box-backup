# Termux View

Terminal view with main app removed
