# Simple Telegram Service Bot

### Features

* Delete and ban channel messages
* Delete and warn non-member messages
* Delete service messages

### Usage

Fill `config.json` from `_config.json` and just run it