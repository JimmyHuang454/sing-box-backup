package io.nekohasekai.sfa.constant

object Path {
    const val SETTINGS_DATABASE_PATH = "settings.db"
    const val PROFILES_DATABASE_PATH = "profiles.db"
}