package io.nekohasekai.sfa.constant

object ServiceMode {
    const val NORMAL = "normal"
    const val VPN = "vpn"
}