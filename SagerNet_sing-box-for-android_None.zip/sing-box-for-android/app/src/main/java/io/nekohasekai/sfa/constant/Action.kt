package io.nekohasekai.sfa.constant

object Action {
    const val SERVICE = "io.nekohasekai.sfa.SERVICE"
    const val SERVICE_CLOSE = "io.nekohasekai.sfa.SERVICE_CLOSE"
    const val SERVICE_RELOAD = "io.nekohasekai.sfa.SERVICE_RELOAD"
}