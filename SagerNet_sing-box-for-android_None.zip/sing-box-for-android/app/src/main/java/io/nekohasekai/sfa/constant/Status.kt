package io.nekohasekai.sfa.constant

enum class Status {
    Stopped,
    Starting,
    Started,
    Stopping,
}