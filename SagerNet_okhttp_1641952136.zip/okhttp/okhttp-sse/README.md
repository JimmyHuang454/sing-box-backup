OkHttp Server-Sent Events
=========================

Experimental support for server-sent events.
API is not considered stable and may change at any time.

### Download

```kotlin
testImplementation("com.squareup.okhttp3:okhttp-sse:4.9.3")
```
