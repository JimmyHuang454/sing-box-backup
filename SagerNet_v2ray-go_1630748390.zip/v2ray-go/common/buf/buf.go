// Package buf provides a light-weight memory allocation mechanism.
package buf

//go:generate go run github.com/Shadowsocks-NET/v2ray-go/v4/common/errors/errorgen
