// Package crypto provides common crypto libraries for V2Ray.
package crypto

//go:generate go run github.com/Shadowsocks-NET/v2ray-go/v4/common/errors/errorgen
