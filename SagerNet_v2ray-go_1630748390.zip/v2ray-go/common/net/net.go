// Package net is a drop-in replacement to Golang's net package, with some more functionalities.
package net

//go:generate go run github.com/Shadowsocks-NET/v2ray-go/v4/common/errors/errorgen
