package taggedimpl

//go:generate go run github.com/Shadowsocks-NET/v2ray-go/v4/common/errors/errorgen
