// Package socks provides implements of Socks protocol 4, 4a and 5.
package socks

//go:generate go run github.com/Shadowsocks-NET/v2ray-go/v4/common/errors/errorgen
